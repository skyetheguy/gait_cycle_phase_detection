#pragma once
#include "processSignal.h"
#include "constants.h"
#include <iostream>
#include "mainwindow.h"
#include <QApplication>
#include <QString>

using namespace std;


class gaitCycle 
{

public:

    gaitCycle(MainWindow *w);

    int processReadings(sensorData currentData);

	bool isHeelStrike(float zAccel, int currTime);

	bool isToeOff(float zAccel, int currTime); 

private:

	processSignal xAccelSignal;
	processSignal yAccelSignal;
	processSignal zAccelSignal;

	processSignal xGyroSignal;
	processSignal yGyroSignal;
	processSignal zGyroSignal;

	int lastState;
	int lastStateChangeTime;
    MainWindow *wSelfPtr;
};
