#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <string>
#include <iostream>

using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void infoWindowAppendData(QString data);
    void infoWindowFilterdAppendData(QString data);

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
