#include "mainwindow.h"
#include <QApplication>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "gaitCycle.h"
#include "sensorData.h"
#include "processSignal.h"
#include "constants.h"
#include <chrono>
#include <thread>

#define CSV_LINE_LENGTH 20

using namespace std;
using namespace std::this_thread; // sleep_for, sleep_until
using namespace std::chrono; // nanoseconds, system_clock, seconds


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow *wSelfPtr; // SHOULD BE FIXED

    wSelfPtr = new MainWindow;

    wSelfPtr->show();

    // USED FOR CONVERTING STD::STRING TO QSTRING
    string str;
    QString qstr;


    gaitCycle *mainCycle = new gaitCycle(wSelfPtr);

        int state; // Current state or phase of the gait cycle

        sensorData currentData;


        // OPEN FILE FOR READING
        ifstream infile;
        infile.open("/home/skye/QT_Projs/dephy_1/walkData1.csv");

        // USED FOR READING FROM FILE
        string value;
        vector<string> lineData;


        // WHILE NOT AT EOF KEEP READING LINES WHILE PROCESSING EACH AS WE READ
        while (infile.good())
        {

            for (int i = 0; i <= (CSV_LINE_LENGTH - 2); i++)
            {
                getline(infile, value, ',');
                lineData.push_back(value);

            }

            currentData.setTime( std::stoi(lineData[1], NULL, 10) );
            str = lineData[1];

            currentData.setXAccel( std::stoi(lineData[2], NULL, 10) );
            str = str + "\t" + lineData[2];

            currentData.setYAccel( std::stoi(lineData[3], NULL, 10) );
            str = str + "\t" + lineData[3];

            currentData.setZAccel( std::stoi(lineData[4], NULL, 10) );
            str = str + "\t" + lineData[4];

            currentData.setXGyro( std::stoi(lineData[5], NULL, 10) );
            str = str + "\t" + lineData[5];

            currentData.setYGyro( std::stoi(lineData[6], NULL, 10) );
            str = str + "\t" + lineData[6];

            currentData.setZGyro( std::stoi(lineData[7], NULL, 10) );
            str = str + "\t" + lineData[7];

            qstr = QString::fromStdString(str);
            wSelfPtr->infoWindowAppendData(qstr);


            // PROCESS THE DATA JUST TAKEN IN
            state = mainCycle->processReadings(currentData);

            lineData.clear();
            //sleep_for(nanoseconds(10000000));
        }

        //cout <<"finished loop" << endl;


        infile.close(); // CLOSE FILE



    return a.exec();
}


